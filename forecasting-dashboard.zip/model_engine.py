
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from prophet import Prophet
from sklearn.metrics import mean_absolute_error, mean_squared_error
from keras.models import Sequential
from keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred, squared=False)
    mape = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-10))) * 100
    return round(mae, 2), round(rmse, 2), f"{mape:.2f}%"

def run_model(df, item_code, model_choice, forecast_months, return_history=False):
    # Filter data
    df_item = df[df["item_code"] == item_code].copy()
    if df_item.empty:
        print("[ERROR] Data untuk item_code tidak ditemukan.")
        return pd.DataFrame(), None, {"MAE": 0, "RMSE": 0, "MAPE": "0%"}
    if "sales_date" not in df_item.columns:
        print("[ERROR] Kolom 'sales_date' tidak ditemukan.")
        return pd.DataFrame(), None, {"MAE": 0, "RMSE": 0, "MAPE": "0%"}
    df_item["sales_date"] = pd.to_datetime(df_item["sales_date"], errors="coerce")

    if 'sales_date' not in df.columns:
        raise ValueError("Kolom 'sales_date' tidak ditemukan di dataset.")

    df['date'] = pd.to_datetime(df['sales_date'])  # Aliasing for consistency

    df_item = df[df["item_code"] == item_code]
    df_item = df_item.sort_values("date")
    df_item = df_item[["date", "sales_qty"]].dropna()
    df_item.set_index("date", inplace=True)
    y = df_item["sales_qty"].astype(float)

    if len(y) < 24:
        return pd.DataFrame(), plt.figure(), {"MAE": 0, "RMSE": 0, "MAPE": "0%"}, None, None

    y_train = y[:-forecast_months]
    y_test = y[-forecast_months:]

    if model_choice == "ARIMA":
        model = ARIMA(y_train, order=(1, 1, 1)).fit()
        forecast = model.forecast(steps=forecast_months)
        y_pred = forecast
        result_df = pd.DataFrame({
            "Date": y_test.index,
            "Forecast": forecast.values,
            "Actual": y_test
        })
        mae, rmse, mape = evaluate(y_test, forecast.values)

    elif model_choice == "SARIMAX":
        exog_cols = [col for col in df.columns if col not in ["item_code", "sales_qty", "sales_date", "date"]]
        exog_data = df[df["item_code"] == item_code].sort_values("date")[exog_cols]
        exog_data.index = pd.to_datetime(df_item.index)
        exog_train = exog_data[:-forecast_months]
        exog_test = exog_data[-forecast_months:]
        model = SARIMAX(y_train, exog=exog_train, order=(1,1,1), seasonal_order=(1,1,1,12)).fit(disp=False)
        forecast = model.forecast(steps=forecast_months, exog=exog_test)
        y_pred = forecast
        result_df = pd.DataFrame({
            "Date": y_test.index,
            "Forecast": forecast.values,
            "Actual": y_test
        })
        mae, rmse, mape = evaluate(y_test, forecast.values)

    elif model_choice == "Prophet":
        prophet_df = df_item.reset_index().rename(columns={"date": "ds", "sales_qty": "y"})
        m = Prophet()
        m.fit(prophet_df)
        future = m.make_future_dataframe(periods=forecast_months, freq='MS')
        forecast = m.predict(future)
        forecast_df = forecast[["ds", "yhat"]].set_index("ds")
        forecast_result = forecast_df[-forecast_months:]
        y_pred = forecast_result["yhat"]
        result_df = pd.DataFrame({
            "Date": y_test.index,
            "Forecast": y_pred,
            "Actual": y_test
        })
        mae, rmse, mape = evaluate(y_test, y_pred)

    elif model_choice == "LSTM":
        scaler = MinMaxScaler()
        y_scaled = scaler.fit_transform(y.values.reshape(-1, 1))

        def create_dataset(series, look_back=1):
            X, Y = [], []
            for i in range(len(series)-look_back):
                X.append(series[i:(i+look_back), 0])
                Y.append(series[i + look_back, 0])
            return np.array(X), np.array(Y)

        look_back = 3
        X_all, Y_all = create_dataset(y_scaled, look_back)
        split = len(y) - forecast_months - look_back
        X_train, X_test = X_all[:split], X_all[split:]
        Y_train, Y_test = Y_all[:split], Y_all[split:]

        X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
        X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

        model = Sequential()
        model.add(LSTM(50, input_shape=(look_back, 1)))
        model.add(Dense(1))
        model.compile(loss='mean_squared_error', optimizer='adam')
        model.fit(X_train, Y_train, epochs=50, batch_size=1, verbose=0)

        predictions = model.predict(X_test)
        predictions_inv = scaler.inverse_transform(predictions)
        Y_test_inv = scaler.inverse_transform(Y_test.reshape(-1, 1))

        y_pred = predictions_inv.flatten()
        y_true = Y_test_inv.flatten()
        dates = y.index[-len(y_true):]

        min_len = min(len(dates), len(y_pred), len(y_true))
        last_date = df_item["sales_date"].max()
        future_dates = pd.date_range(last_date + pd.offsets.MonthBegin(1), periods=forecast_months, freq='MS')
        data = list(zip(future_dates[:min_len], y_pred[-min_len:], y_true[-min_len:]))
        result_df = pd.DataFrame(data, columns=["Date", "Forecast", "Actual"])
        mae, rmse, mape = evaluate(y_true, y_pred)

    else:
        return pd.DataFrame(), plt.figure(), {"MAE": 0, "RMSE": 0, "MAPE": "0%"}, None, None

    fig, ax = plt.subplots()
    ax.plot(result_df["Date"], result_df["Forecast"], label="Forecast")
    ax.plot(result_df["Date"], result_df["Actual"], label="Actual")
    ax.set_title(f"{model_choice} Forecast")
    ax.set_ylabel("Monthly Quantity")
    ax.legend()

    if return_history:
        return result_df, fig, {"MAE": mae, "RMSE": rmse, "MAPE": mape}, y_test, y_pred

    return result_df, fig, {"MAE": mae, "RMSE": rmse, "MAPE": mape}
