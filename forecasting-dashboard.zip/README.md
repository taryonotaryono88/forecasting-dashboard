# 📊 Forecasting Dashboard

A Streamlit app to evaluate and forecast demand using ARIMA, SARIMAX, Prophet, and LSTM models.

## Features
- Upload Excel dataset
- Select forecasting model
- Visualize forecast vs actual
- Export PDF forecast report

## Deploy to Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/USERNAME/forecasting-dashboard)
