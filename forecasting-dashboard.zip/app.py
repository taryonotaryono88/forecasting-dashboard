
import streamlit as st
import pandas as pd
from model_engine import run_model
from seasonal_flags import add_seasonal_flags
from generate_forecast_pdf import generate_forecast_pdf
from io import BytesIO
import seaborn as sns
import matplotlib.pyplot as plt
import base64
from datetime import datetime

st.set_page_config(page_title="📊 Forecasting Dashboard", layout="wide")

st.title("📊 Forecasting Dashboard with Evaluation & Prediction")

uploaded_file = st.sidebar.file_uploader("Upload Dataset", type=["xlsx"], key="uploader1")
if uploaded_file:
    df_uploaded = pd.read_excel(uploaded_file)
    if 'sales_date' not in df_uploaded.columns:
        st.error("Kolom 'sales_date' tidak ditemukan.")
    else:
        df_uploaded['sales_date'] = pd.to_datetime(df_uploaded['sales_date'])
        df_uploaded = add_seasonal_flags(df_uploaded)
        item_codes = df_uploaded["item_code"].unique()

        item_code = st.sidebar.selectbox("Select Item Code", item_codes, key="item_dropdown")
        model_choice = st.sidebar.selectbox("Select Forecasting Model", ["ARIMA", "SARIMAX", "Prophet", "LSTM"], key="model_dropdown")
        forecast_months = st.sidebar.slider("Months to Forecast", 3, 24, 12)

        tab1, tab2 = st.tabs(["📈 Model Evaluation", "🔮 Forecast Future"])

        # --- MODEL EVALUATION ---
        with tab1:
            st.header("📊 Historical Model Evaluation")
            filtered_df = df_uploaded[df_uploaded["item_code"] == item_code]

            result_df, fig, metrics, y_true, y_pred = run_model(filtered_df, item_code, model_choice, forecast_months, return_history=True)

            if result_df.empty:
                st.warning("Not enough data to evaluate.")
            else:
                col1, col2, col3 = st.columns(3)
                col1.metric("MAE", metrics.get("MAE", "N/A"))
                col2.metric("RMSE", metrics.get("RMSE", "N/A"))
                col3.metric("MAPE", metrics.get("MAPE", "N/A"))

                st.subheader("📈 Forecast vs Actual")
                fig_eval, ax = plt.subplots()
                ax.plot(result_df["Date"], result_df["Forecast"], label="Forecast")
                ax.plot(result_df["Date"], result_df["Actual"], label="Actual")
                ax.set_title(f"{model_choice} Forecast vs Actual")
                ax.set_ylabel("Monthly Quantity")
                ax.legend()
                st.pyplot(fig_eval)

                st.subheader("📊 Monthly Forecast Error Heatmap")
                df_heatmap = result_df.copy()
                df_heatmap["Year"] = df_heatmap["Date"].dt.year
                df_heatmap["Month"] = df_heatmap["Date"].dt.strftime("%b")
                df_heatmap["Error"] = abs(df_heatmap["Forecast"] - df_heatmap["Actual"])

                pivot_table = df_heatmap.pivot_table(index="Month", columns="Year", values="Error", aggfunc="mean")
                pivot_table = pivot_table.reindex(["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                                   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])

                fig_hm, ax_hm = plt.subplots(figsize=(10, 4))
                sns.heatmap(pivot_table, annot=True, fmt=".1f", cmap="Reds", ax=ax_hm)
                st.pyplot(fig_hm)

        # --- FORECASTING ---
        with tab2:
            st.header("🔮 Forecast Future Demand")
            filtered_df = df_uploaded[df_uploaded["item_code"] == item_code]

            result_df, fig, metrics = run_model(filtered_df, item_code, model_choice, forecast_months)

            if result_df.empty:
                st.warning("Not enough data for forecasting.")
            else:
                st.subheader("📈 Forecast for Next {} Months".format(forecast_months))
                forecast_only = result_df.tail(forecast_months)
                fig_fore, ax = plt.subplots()
                ax.plot(forecast_only["Date"], forecast_only["Forecast"], label="Forecast")
                ax.set_title(f"{model_choice} Forecast (Next {forecast_months} months)")
                ax.set_ylabel("Monthly Quantity")
                ax.legend()
                st.pyplot(fig_fore)

                st.subheader("📄 Forecast Table")
                st.dataframe(result_df)

                pdf_buffer = generate_forecast_pdf(result_df, metrics, item_code, model_choice, fig)
                st.download_button(
                    label="📄 Download Forecast PDF",
                    data=pdf_buffer,
                    file_name=f"forecast_{item_code}_{datetime.now().date()}.pdf",
                    mime="application/pdf"
                )
