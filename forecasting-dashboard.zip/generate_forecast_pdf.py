
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from io import BytesIO
import matplotlib.pyplot as plt

def generate_forecast_pdf(result_df, metrics, item_code, model_choice, fig):
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Title
    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, height - 50, f"Forecast Report: {item_code} ({model_choice})")

    # Metrics
    c.setFont("Helvetica", 12)
    c.drawString(50, height - 80, f"MAE: {metrics.get('MAE', 'N/A')} | RMSE: {metrics.get('RMSE', 'N/A')} | MAPE: {metrics.get('MAPE', 'N/A')}")

    # Forecast Table
    c.drawString(50, height - 110, "Top Forecasted Values:")
    y = height - 130
    for _, row in result_df.head(10).iterrows():
        date = row['Date'].strftime('%Y-%m') if hasattr(row['Date'], 'strftime') else str(row['Date'])
        c.drawString(50, y, f"{date} | Forecast: {row['Forecast']:.2f} | Actual: {row['Actual']:.2f}")
        y -= 15
        if y < 100:
            c.showPage()
            y = height - 50

    # Plot
    if fig:
        try:
            img_buffer = BytesIO()
            fig.savefig(img_buffer, format='PNG')
            img_buffer.seek(0)
            c.drawImage(ImageReader(img_buffer), 50, 100, width=500, preserveAspectRatio=True, mask='auto')
        except Exception as e:
            c.drawString(50, 100, f"[!] Failed to render plot: {e}")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer
