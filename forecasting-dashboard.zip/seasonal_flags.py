
import pandas as pd

def add_seasonal_flags(df, date_col='sales_date'):
    df[date_col] = pd.to_datetime(df[date_col])
    df['is_ramadhan'] = df[date_col].dt.month.isin([3, 4, 5]).astype(int)
    df['is_imlek'] = df[date_col].dt.month == 2
    return df
